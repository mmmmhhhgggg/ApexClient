using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

internal static class ApexSetup
{
    private const string ProductName = "Apple Client";
    private const string LegacyProgramDirectory = "Apex Client";
    private const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\ApexClient";
    private static readonly string DefaultInstallPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "Programs", LegacyProgramDirectory);

    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            if (args.Length > 0 && args[0] == "--verify")
                return VerifyPayload();
            if (args.Length > 1 && args[0] == "--remove")
                return RemoveInstalledFiles(args[1]);
            if (args.Length > 1 && args[0] == "--uninstall")
            {
                StartRemoval(args[1]);
                return 0;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new InstallerForm());
            return 0;
        }
        catch (Exception exception)
        {
            MessageBox.Show(exception.Message, ProductName + " - błąd instalacji",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }

    private static int VerifyPayload()
    {
        string[] resources = {
            "payload.ApexClient.exe",
            "payload.ApexClientHud-1.21.11.jar",
            "payload.ApexClientHud-26.3.jar",
            "payload.README.txt"
        };
        Assembly assembly = Assembly.GetExecutingAssembly();
        foreach (string name in resources)
        {
            using (Stream stream = assembly.GetManifestResourceStream(name))
            {
                if (stream == null)
                    throw new InvalidDataException("Brak pliku w instalatorze: " + name);
                using (SHA256 sha = SHA256.Create())
                    Console.WriteLine(name + " " + BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", ""));
            }
        }
        return 0;
    }

    private static void Install(string directory, bool desktopShortcut, IProgress<string> progress)
    {
        string target = Path.GetFullPath(directory);
        if (target.IndexOfAny(Path.GetInvalidPathChars()) >= 0 || target.IndexOf('"') >= 0 ||
            target.IndexOf('%') >= 0 || target.IndexOf('&') >= 0)
            throw new InvalidOperationException("Ścieżka instalacji zawiera niedozwolone znaki.");

        Directory.CreateDirectory(target);
        progress.Report("Kopiowanie launchera...");
        ExtractResource("payload.ApexClient.exe", Path.Combine(target, "ApexClient.exe"));
        string mods = Path.Combine(target, "mods");
        Directory.CreateDirectory(mods);
        progress.Report("Kopiowanie obsługiwanych modów Apple...");
        ExtractResource("payload.ApexClientHud-1.21.11.jar",
            Path.Combine(mods, "ApexClientHud-1.21.11.jar"));
        ExtractResource("payload.ApexClientHud-26.3.jar",
            Path.Combine(mods, "ApexClientHud-26.3.jar"));
        ExtractResource("payload.README.txt", Path.Combine(target, "README.txt"));
        ExtractResource("payload.ApexClient.exe", Path.Combine(target, "Uninstall Apple Client.exe"));

        progress.Report("Tworzenie skrótów...");
        string legacyMenu = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), LegacyProgramDirectory);
        string legacyShortcut = Path.Combine(legacyMenu, "Apex Client.lnk");
        string legacyUninstallShortcut = Path.Combine(legacyMenu, "Odinstaluj Apex Client.lnk");
        if (File.Exists(legacyShortcut)) File.Delete(legacyShortcut);
        if (File.Exists(legacyUninstallShortcut)) File.Delete(legacyUninstallShortcut);
        if (Directory.Exists(legacyMenu) && Directory.GetFileSystemEntries(legacyMenu).Length == 0)
            Directory.Delete(legacyMenu);
        string menu = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), ProductName);
        Directory.CreateDirectory(menu);
        CreateShortcut(Path.Combine(menu, "Apple Client.lnk"), Path.Combine(target, "ApexClient.exe"));
        CreateShortcut(Path.Combine(menu, "Odinstaluj Apple Client.lnk"),
            Path.Combine(target, "Uninstall Apple Client.exe"), "--uninstall \"" + target + "\"");
        if (desktopShortcut)
            CreateShortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                "Apple Client.lnk"), Path.Combine(target, "ApexClient.exe"));
        string legacyDesktopShortcut = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
            "Apex Client.lnk");
        if (File.Exists(legacyDesktopShortcut)) File.Delete(legacyDesktopShortcut);

        progress.Report("Zapisywanie informacji deinstalatora...");
        using (RegistryKey key = Registry.CurrentUser.CreateSubKey(UninstallKey))
        {
            if (key == null) throw new InvalidOperationException("Nie można zapisać wpisu deinstalatora.");
            key.SetValue("DisplayName", ProductName);
            key.SetValue("DisplayVersion", "1.0.0");
            key.SetValue("Publisher", ProductName);
            key.SetValue("InstallLocation", target);
            key.SetValue("DisplayIcon", Path.Combine(target, "ApexClient.exe"));
            key.SetValue("UninstallString", "\"" + Path.Combine(target, "Uninstall Apple Client.exe") +
                "\" --uninstall \"" + target + "\"");
            key.SetValue("NoModify", 1, RegistryValueKind.DWord);
            key.SetValue("NoRepair", 1, RegistryValueKind.DWord);
        }
    }

    private static void ExtractResource(string resourceName, string destination)
    {
        using (Stream input = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
        {
            if (input == null) throw new InvalidDataException("Brak pliku w instalatorze: " + resourceName);
            string temporary = destination + ".apex-setup";
            try
            {
                using (FileStream output = new FileStream(temporary, FileMode.Create, FileAccess.Write, FileShare.None))
                    input.CopyTo(output);
                if (File.Exists(destination)) File.Delete(destination);
                File.Move(temporary, destination);
            }
            finally
            {
                if (File.Exists(temporary)) File.Delete(temporary);
            }
        }
    }

    private static void CreateShortcut(string shortcutPath, string target, string arguments = "")
    {
        Type shellType = Type.GetTypeFromProgID("WScript.Shell");
        if (shellType == null) throw new InvalidOperationException("Windows Script Host jest niedostępny.");
        object shell = Activator.CreateInstance(shellType);
        object shortcut = shellType.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod,
            null, shell, new object[] { shortcutPath });
        Type shortcutType = shortcut.GetType();
        shortcutType.InvokeMember("TargetPath", BindingFlags.SetProperty, null, shortcut, new object[] { target });
        shortcutType.InvokeMember("Arguments", BindingFlags.SetProperty, null, shortcut, new object[] { arguments });
        shortcutType.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, shortcut,
            new object[] { Path.GetDirectoryName(target) });
        shortcutType.InvokeMember("Description", BindingFlags.SetProperty, null, shortcut,
            new object[] { ProductName });
        shortcutType.InvokeMember("Save", BindingFlags.InvokeMethod, null, shortcut, null);
        if (System.Runtime.InteropServices.Marshal.IsComObject(shortcut))
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
        if (System.Runtime.InteropServices.Marshal.IsComObject(shell))
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);
    }

    private static void StartRemoval(string target)
    {
        string fullTarget = Path.GetFullPath(target);
        string temporaryHelper = Path.Combine(Path.GetTempPath(),
            "ApexClientRemove-" + Guid.NewGuid().ToString("N") + ".exe");
        File.Copy(Assembly.GetExecutingAssembly().Location, temporaryHelper);
        Process.Start(new ProcessStartInfo
        {
            FileName = temporaryHelper,
            Arguments = "--remove \"" + fullTarget + "\"",
            UseShellExecute = false,
            CreateNoWindow = true
        });
    }

    private static int RemoveInstalledFiles(string target)
    {
        Thread.Sleep(1200);
        string fullTarget = Path.GetFullPath(target);
        string localPrograms = Path.GetFullPath(Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs"));
        if (!fullTarget.StartsWith(localPrograms + Path.DirectorySeparatorChar,
                StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Odmowa usunięcia ścieżki poza katalogiem instalacji Apex.");

        using (RegistryKey key = Registry.CurrentUser.OpenSubKey(UninstallKey))
        {
            string registered = key == null ? null : key.GetValue("InstallLocation") as string;
            if (!String.Equals(registered, fullTarget, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Ścieżka nie zgadza się z wpisem instalacyjnym Apex.");
        }

        string menu = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), ProductName);
        if (Directory.Exists(menu)) Directory.Delete(menu, true);
        string legacyMenu = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), LegacyProgramDirectory);
        foreach (string shortcut in new[] { "Apex Client.lnk", "Odinstaluj Apex Client.lnk" })
        {
            string oldPath = Path.Combine(legacyMenu, shortcut);
            if (File.Exists(oldPath)) File.Delete(oldPath);
        }
        if (Directory.Exists(legacyMenu) && Directory.GetFileSystemEntries(legacyMenu).Length == 0)
            Directory.Delete(legacyMenu);
        foreach (string shortcut in new[] { "Apex Client.lnk", "Apple Client.lnk" })
        {
            string desktopShortcut = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), shortcut);
            if (File.Exists(desktopShortcut)) File.Delete(desktopShortcut);
        }
        Registry.CurrentUser.DeleteSubKeyTree(UninstallKey, false);
        if (Directory.Exists(fullTarget)) Directory.Delete(fullTarget, true);
        return 0;
    }

    private sealed class InstallerForm : Form
    {
        private readonly TextBox directoryBox = new TextBox();
        private readonly CheckBox desktopBox = new CheckBox();
        private readonly CheckBox launchBox = new CheckBox();
        private readonly Button installButton = new Button();
        private readonly Label statusLabel = new Label();
        private readonly ProgressBar progress = new ProgressBar();

        internal InstallerForm()
        {
            Text = ProductName + " - instalator";
            ClientSize = new Size(560, 270);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(13, 19, 29);
            ForeColor = Color.FromArgb(230, 239, 249);
            Font = new Font("Segoe UI", 9F);

            Label title = new Label
            {
                Text = "APPLE CLIENT",
                Font = new Font("Segoe UI Semibold", 22F, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 210, 255),
                Location = new Point(28, 22),
                AutoSize = true
            };
            Controls.Add(title);
            Label subtitle = new Label
            {
                Text = "Instalacja launchera dla bieżącego użytkownika - bez uprawnień administratora.",
                Location = new Point(30, 66),
                Size = new Size(500, 35),
                ForeColor = Color.Gainsboro
            };
            Controls.Add(subtitle);
            Label locationLabel = new Label
            {
                Text = "Folder instalacji",
                Location = new Point(30, 111),
                AutoSize = true
            };
            Controls.Add(locationLabel);
            directoryBox.Text = DefaultInstallPath;
            directoryBox.SetBounds(30, 133, 400, 27);
            Controls.Add(directoryBox);
            Button browse = new Button { Text = "Przeglądaj...", Bounds = new Rectangle(438, 132, 94, 29) };
            browse.Click += delegate
            {
                using (FolderBrowserDialog dialog = new FolderBrowserDialog())
                {
                    dialog.SelectedPath = directoryBox.Text;
                    dialog.Description = "Wybierz folder, w którym Apple Client zostanie zainstalowany.";
                    if (dialog.ShowDialog(this) == DialogResult.OK) directoryBox.Text = dialog.SelectedPath;
                }
            };
            Controls.Add(browse);
            desktopBox.Text = "Utwórz skrót na pulpicie";
            desktopBox.Checked = true;
            desktopBox.SetBounds(30, 171, 240, 24);
            Controls.Add(desktopBox);
            launchBox.Text = "Uruchom Apple Client po instalacji";
            launchBox.Checked = true;
            launchBox.SetBounds(30, 197, 280, 24);
            Controls.Add(launchBox);
            progress.SetBounds(30, 228, 320, 18);
            progress.Style = ProgressBarStyle.Marquee;
            progress.Visible = false;
            Controls.Add(progress);
            statusLabel.SetBounds(30, 228, 390, 20);
            statusLabel.ForeColor = Color.Silver;
            Controls.Add(statusLabel);
            installButton.Text = "Zainstaluj";
            installButton.SetBounds(420, 218, 112, 34);
            installButton.FlatStyle = FlatStyle.Flat;
            installButton.BackColor = Color.FromArgb(0, 125, 160);
            installButton.ForeColor = Color.White;
            installButton.Click += InstallClicked;
            Controls.Add(installButton);
        }

        private void InstallClicked(object sender, EventArgs e)
        {
            installButton.Enabled = false;
            progress.Visible = true;
            statusLabel.Text = "Przygotowywanie...";
            try
            {
                Install(directoryBox.Text, desktopBox.Checked, new Progress<string>(message =>
                    statusLabel.Text = message));
                if (launchBox.Checked)
                {
                    Process.Start(Path.Combine(Path.GetFullPath(directoryBox.Text), "ApexClient.exe"));
                }
                MessageBox.Show(this, "Apple Client został zainstalowany.", ProductName,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
            }
            catch (Exception exception)
            {
                installButton.Enabled = true;
                progress.Visible = false;
                statusLabel.Text = "Instalacja nie powiodła się.";
                MessageBox.Show(this, exception.Message, ProductName + " - błąd instalacji",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
