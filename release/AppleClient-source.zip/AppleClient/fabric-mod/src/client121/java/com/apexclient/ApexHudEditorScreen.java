package com.apexclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Map;

public final class ApexHudEditorScreen extends Screen {
    private final Screen parent;
    private String draggingWidget;
    private int dragOffsetX;
    private int dragOffsetY;
    private int draggedX;
    private int draggedY;

    public ApexHudEditorScreen(Screen parent) {
        super(Component.literal("Apple HUD Editor"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ApexHud.setEditorOpen(true);
        addRenderableWidget(Button.builder(Component.literal("DONE"), button -> onClose())
                .bounds(width - 92, height - 32, 78, 22).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        Map<String, List<String>> groups = ApexHud.groupLines(ApexHud.getWidgetLines());
        Map<String, int[]> positions = positionsFor(groups);
        for (Map.Entry<String, List<String>> entry : groups.entrySet()) {
            String widget = entry.getKey();
            int[] position = positions.get(widget);
            if (widget.equals(draggingWidget)) {
                position = new int[] { draggedX, draggedY };
            }
            ApexHud.drawWidget(graphics, widget, entry.getValue(), position[0], position[1],
                    true, mouseX, mouseY);
        }
        graphics.fill(8, height - 42, width - 8, height - 8, 0xD8101724);
        graphics.fill(8, height - 43, width - 8, height - 41, 0xFF00D2FF);
        graphics.drawString(font, "APEX HUD EDITOR - drag any widget; positions save when you release the mouse.",
                16, height - 30, 0xFFE8F5FF, false);
        if (groups.isEmpty()) {
            graphics.drawString(font, "Enable HUD modules in the Apple menu to edit their positions.",
                    16, height - 48, 0xFFB1BECC, false);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        if (event.button() != 0) {
            return false;
        }
        Map<String, List<String>> groups = ApexHud.groupLines(ApexHud.getWidgetLines());
        Map<String, int[]> positions = positionsFor(groups);
        for (Map.Entry<String, List<String>> entry : groups.entrySet()) {
            String widget = entry.getKey();
            int[] position = positions.get(widget);
            int right = position[0] + ApexHud.widgetWidth(widget, entry.getValue());
            int bottom = position[1] + ApexHud.widgetHeight(widget, entry.getValue());
            if (event.x() >= position[0] && event.x() <= right
                    && event.y() >= position[1] && event.y() <= bottom) {
                draggingWidget = widget;
                dragOffsetX = (int) event.x() - position[0];
                dragOffsetY = (int) event.y() - position[1];
                draggedX = position[0];
                draggedY = position[1];
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (draggingWidget == null || event.button() != 0) {
            return super.mouseDragged(event, dragX, dragY);
        }
        Map<String, List<String>> groups = ApexHud.groupLines(ApexHud.getWidgetLines());
        List<String> lines = groups.get(draggingWidget);
        if (lines != null) {
            int maxX = Math.max(0, width - ApexHud.widgetWidth(draggingWidget, lines));
            int maxY = Math.max(0, height - ApexHud.widgetHeight(draggingWidget, lines));
            draggedX = Math.max(0, Math.min(maxX, (int) event.x() - dragOffsetX));
            draggedY = Math.max(0, Math.min(maxY, (int) event.y() - dragOffsetY));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (draggingWidget != null && event.button() == 0) {
            ApexClientConfig.setHudPosition(draggingWidget, draggedX, draggedY);
            draggingWidget = null;
            return true;
        }
        return super.mouseReleased(event);
    }

    private Map<String, int[]> positionsFor(Map<String, List<String>> groups) {
        Map<String, int[]> positions = new java.util.LinkedHashMap<>();
        int defaultY = 8;
        for (Map.Entry<String, List<String>> entry : groups.entrySet()) {
            String widget = entry.getKey();
            positions.put(widget, ApexClientConfig.getHudPosition(widget, 8, defaultY));
            defaultY += ApexHud.widgetHeight(widget, entry.getValue()) + 6;
        }
        return positions;
    }

    @Override
    public void onClose() {
        ApexHud.setEditorOpen(false);
        Minecraft.getInstance().setScreenAndShow(parent);
    }

    @Override
    public void removed() {
        ApexHud.setEditorOpen(false);
    }
}
