package com.apexclient;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.KeyMapping.Category;

public final class ApexClientMod implements ClientModInitializer {
    private KeyMapping openMenu;

    @Override
    public void onInitializeClient() {
        ApexHud.register();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.apexclient.open_menu",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_RSHIFT,
                Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.consumeClick()) {
                client.setScreen(new ApexConfigScreen());
            }
        });
    }
}
