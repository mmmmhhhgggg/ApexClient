package com.apexclient;

import java.util.List;

public final class ApexFeatures {
    public static final String HUD = "HUD";
    public static final String GAMEPLAY = "Gameplay";
    public static final String VISUALS = "Visuals";
    public static final String SOUND = "Sound";
    public static final String COMMUNITY = "Community";
    public static final String MODS = "Mods";
    public static final String SETTINGS = "Settings";

    public static final List<String> CATEGORIES = List.of(
            HUD, GAMEPLAY, VISUALS, SOUND, COMMUNITY, MODS, SETTINGS
    );

    public static final List<Feature> ALL = List.of(
            new Feature(HUD, "fps", "FPS Counter", "Live frames per second."),
            new Feature(HUD, "cps", "CPS - Left / Right", "Left and right clicks in the last second."),
            new Feature(HUD, "keystrokes", "Keystrokes", "Live WASD and mouse button state."),
            new Feature(HUD, "coordinates", "Coordinates", "Player position and facing direction."),
            new Feature(HUD, "armor", "Armor Status", "Armor and held item durability."),
            new Feature(HUD, "effects", "Potion Effects", "Active effects and remaining duration."),
            new Feature(HUD, "clock", "Clock", "Current real-world time."),
            new Feature(HUD, "network_memory", "Ping + Memory", "Server latency and Java memory use."),
            new Feature(HUD, "biome", "Biome", "Current biome identifier."),
            new Feature(HUD, "movement_speed", "Movement Speed", "Horizontal player speed in blocks per second."),
            new Feature(HUD, "world_time", "World Time", "Minecraft day time and day number."),
            new Feature(HUD, "dimension", "Dimension", "Current world dimension."),
            new Feature(HUD, "chunk", "Chunk Coordinates", "Current chunk X and Z coordinates."),
            new Feature(HUD, "tnt_timer", "TNT Timer", "Fuse countdown for the nearest primed TNT."),
            new Feature(HUD, "image", "Image / GIF / MP4", "Display a local image or looping animation.")
    );

    private ApexFeatures() {
    }

    public static final class Feature {
        public final String category;
        public final String id;
        public final String label;
        public final String description;

        private Feature(String category, String id, String label, String description) {
            this.category = category;
            this.id = id;
            this.label = label;
            this.description = description;
        }
    }
}
