package com.apexclient;

import org.jcodec.api.FrameGrab;
import org.jcodec.api.JCodecException;
import org.jcodec.common.io.NIOUtils;
import org.jcodec.common.io.SeekableByteChannel;
import org.jcodec.api.PictureWithMetadata;
import org.jcodec.scale.AWTUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageInputStream;
import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReference;

public final class ApexMedia {
    private static final Logger LOGGER = LoggerFactory.getLogger("Apex Client Media");
    private static final int DISPLAY_WIDTH = 320;
    private static final int DISPLAY_HEIGHT = 180;
    private static final int MAX_IMAGE_DIMENSION = 4096;
    private static final long MAX_GIF_PIXELS = 20_000_000L;
    private static final int MAX_GIF_FRAMES = 120;
    private static final ExecutorService DECODER = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Apex media decoder");
        thread.setDaemon(true);
        return thread;
    });
    private static volatile BufferedImage currentFrame;
    private static volatile String status = "Choose a local media file.";
    private static String activePath = "";
    private static long generation;
    private static Future<?> playbackTask;

    private ApexMedia() {
    }

    public static void chooseFile() {
        AtomicReference<Path> selected = new AtomicReference<>();
        Runnable showChooser = () -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Choose Apex HUD media");
            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            chooser.setAcceptAllFileFilterUsed(false);
            chooser.addChoosableFileFilter(new FileNameExtensionFilter(
                    "Images and animations (PNG, JPG, JPEG, GIF, MP4)", "png", "jpg", "jpeg", "gif", "mp4"));
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                selected.set(chooser.getSelectedFile().toPath().toAbsolutePath().normalize());
            }
        };

        try {
            if (SwingUtilities.isEventDispatchThread()) {
                showChooser.run();
            } else {
                SwingUtilities.invokeAndWait(showChooser);
            }
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            LOGGER.warn("Opening the Apex media picker was interrupted", exception);
            return;
        } catch (InvocationTargetException exception) {
            LOGGER.error("Could not open the Apex media picker", exception.getCause());
            return;
        }

        Path path = selected.get();
        if (path == null) {
            return;
        }
        String extension = extension(path);
        if (!List.of("png", "jpg", "jpeg", "gif", "mp4").contains(extension)) {
            LOGGER.warn("Unsupported Apex media file type: {}", path);
            return;
        }
        ApexClientConfig.setMediaPath(path.toString());
        if (!ApexClientConfig.isEnabled("image")) {
            ApexClientConfig.toggle("image");
        }
    }

    public static BufferedImage getCurrentFrame() {
        ensurePlayback();
        return currentFrame;
    }

    public static String getStatus() {
        ensurePlayback();
        return status;
    }

    public static String getLabel() {
        String path = ApexClientConfig.getMediaPath();
        if (path.isBlank()) {
            return "IMAGE  no file selected";
        }
        return "IMAGE  " + Path.of(path).getFileName();
    }

    private static synchronized void ensurePlayback() {
        String path = ApexClientConfig.getMediaPath();
        if (path.equals(activePath)) {
            return;
        }
        activePath = path;
        generation++;
        long taskGeneration = generation;
        if (playbackTask != null) {
            playbackTask.cancel(true);
            playbackTask = null;
        }
        currentFrame = null;
        if (path.isBlank()) {
            status = "Choose a local media file.";
            return;
        }

        File file = Path.of(path).toFile();
        if (!file.isFile()) {
            status = "Media file not found.";
            LOGGER.warn("Apex media file does not exist: {}", path);
            return;
        }
        status = "Loading " + file.getName();
        playbackTask = DECODER.submit(() -> decode(file, extension(file.toPath()), taskGeneration));
    }

    private static void decode(File file, String extension, long taskGeneration) {
        try {
            switch (extension) {
                case "png":
                case "jpg":
                case "jpeg":
                    BufferedImage image = ImageIO.read(file);
                    if (image == null) {
                        throw new IOException("The selected image could not be decoded.");
                    }
                    publish(resizeForDisplay(image), taskGeneration);
                    setStatus("Ready: " + file.getName(), taskGeneration);
                    return;
                case "gif":
                    playGif(file, taskGeneration);
                    return;
                case "mp4":
                    playMp4(file, taskGeneration);
                    return;
                default:
                    throw new IOException("Unsupported media extension: " + extension);
            }
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        } catch (IOException | JCodecException | RuntimeException exception) {
            if (isCurrent(taskGeneration)) {
                status = "Media error: " + exception.getMessage();
                LOGGER.error("Could not decode Apex media file {}", file, exception);
            }
        }
    }

    private static void playGif(File file, long taskGeneration) throws IOException, InterruptedException {
        List<AnimationFrame> frames = readGif(file);
        if (frames.isEmpty()) {
            throw new IOException("The GIF contains no decodable frames.");
        }
        setStatus("Playing: " + file.getName(), taskGeneration);
        while (isCurrent(taskGeneration)) {
            for (AnimationFrame frame : frames) {
                if (!isCurrent(taskGeneration)) {
                    return;
                }
                publish(frame.image, taskGeneration);
                Thread.sleep(frame.delayMillis);
            }
        }
    }

    private static List<AnimationFrame> readGif(File file) throws IOException {
        Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("gif");
        if (!readers.hasNext()) {
            throw new IOException("This Java runtime has no GIF decoder.");
        }
        ImageReader reader = readers.next();
        List<AnimationFrame> frames = new ArrayList<>();
        try (ImageInputStream input = ImageIO.createImageInputStream(file)) {
            if (input == null) {
                throw new IOException("Could not open the GIF file.");
            }
            reader.setInput(input, false, false);
            int frameCount = reader.getNumImages(true);
            if (frameCount > MAX_GIF_FRAMES) {
                throw new IOException("GIF exceeds the 120-frame safety limit.");
            }
            int canvasWidth = positiveAttribute(reader.getStreamMetadata(), "LogicalScreenDescriptor",
                    "logicalScreenWidth", reader.getWidth(0));
            int canvasHeight = positiveAttribute(reader.getStreamMetadata(), "LogicalScreenDescriptor",
                    "logicalScreenHeight", reader.getHeight(0));
            validateDimensions(canvasWidth, canvasHeight);
            long totalPixels = 0;
            BufferedImage canvas = new BufferedImage(canvasWidth, canvasHeight, BufferedImage.TYPE_INT_ARGB);
            String previousDisposal = "none";
            int previousLeft = 0;
            int previousTop = 0;
            int previousWidth = 0;
            int previousHeight = 0;
            BufferedImage previousCanvas = null;

            for (int index = 0; index < frameCount; index++) {
                IIOMetadata metadata = reader.getImageMetadata(index);
                int left = positiveAttribute(metadata, "ImageDescriptor", "imageLeftPosition", 0);
                int top = positiveAttribute(metadata, "ImageDescriptor", "imageTopPosition", 0);
                BufferedImage rawFrame = reader.read(index);
                validateDimensions(rawFrame.getWidth(), rawFrame.getHeight());
                totalPixels += (long) rawFrame.getWidth() * rawFrame.getHeight();
                if (totalPixels > MAX_GIF_PIXELS) {
                    throw new IOException("GIF is too large to safely decode (frame limit exceeded).");
                }

                if ("restoreToBackgroundColor".equals(previousDisposal)) {
                    Graphics2D clear = canvas.createGraphics();
                    clear.setComposite(AlphaComposite.Clear);
                    clear.fillRect(previousLeft, previousTop, previousWidth, previousHeight);
                    clear.dispose();
                } else if ("restoreToPrevious".equals(previousDisposal) && previousCanvas != null) {
                    canvas = copy(previousCanvas);
                }

                String disposal = stringAttribute(metadata, "GraphicControlExtension",
                        "disposalMethod", "none");
                if ("restoreToPrevious".equals(disposal)) {
                    previousCanvas = copy(canvas);
                } else {
                    previousCanvas = null;
                }

                Graphics2D graphics = canvas.createGraphics();
                graphics.drawImage(rawFrame, left, top, null);
                graphics.dispose();

                int delay = positiveAttribute(metadata, "GraphicControlExtension", "delayTime", 10) * 10;
                frames.add(new AnimationFrame(resizeForDisplay(canvas), Math.max(20, Math.min(delay, 10_000))));
                previousDisposal = disposal;
                previousLeft = left;
                previousTop = top;
                previousWidth = rawFrame.getWidth();
                previousHeight = rawFrame.getHeight();
            }
        } finally {
            reader.dispose();
        }
        return frames;
    }

    private static void playMp4(File file, long taskGeneration) throws IOException, JCodecException,
            InterruptedException {
        setStatus("Playing: " + file.getName() + " (H.264)", taskGeneration);
        while (isCurrent(taskGeneration)) {
            int decodedFrames = 0;
            long cycleEndNanos = 0L;
            try (SeekableByteChannel channel = NIOUtils.readableChannel(file)) {
                FrameGrab grab = FrameGrab.createFrameGrab(channel);
                PictureWithMetadata frame;
                double firstTimestamp = Double.NaN;
                long playbackStartNanos = 0L;
                while (isCurrent(taskGeneration) && (frame = grab.getNativeFrameWithMetadata()) != null) {
                    if (Double.isNaN(firstTimestamp)) {
                        firstTimestamp = frame.getTimestamp();
                        playbackStartNanos = System.nanoTime();
                    }
                    if (!Double.isFinite(frame.getTimestamp()) || !Double.isFinite(frame.getDuration())) {
                        throw new IOException("MP4 frame has invalid presentation timing.");
                    }
                    long targetNanos = playbackStartNanos
                            + (long) ((frame.getTimestamp() - firstTimestamp) * 1_000_000_000L);
                    double frameDuration = frame.getDuration() > 0 ? frame.getDuration() : 1.0 / 30.0;
                    cycleEndNanos = playbackStartNanos
                            + (long) ((frame.getTimestamp() - firstTimestamp + frameDuration) * 1_000_000_000L);
                    waitUntil(targetNanos, taskGeneration);
                    if (!isCurrent(taskGeneration)) {
                        return;
                    }
                    BufferedImage decoded = AWTUtil.toBufferedImage(frame.getPicture(), frame.getOrientation());
                    validateDimensions(decoded.getWidth(), decoded.getHeight());
                    publish(resizeForDisplay(decoded), taskGeneration);
                    decodedFrames++;
                }
            }
            if (decodedFrames == 0) {
                throw new IOException("No H.264 video frames were decoded from this MP4.");
            }
            waitUntil(cycleEndNanos, taskGeneration);
        }
    }

    private static void waitUntil(long targetNanos, long taskGeneration) throws InterruptedException {
        while (isCurrent(taskGeneration)) {
            long remaining = targetNanos - System.nanoTime();
            if (remaining <= 0) {
                return;
            }
            long millis = remaining / 1_000_000L;
            int nanos = (int) (remaining % 1_000_000L);
            Thread.sleep(millis, nanos);
        }
    }

    private static BufferedImage resizeForDisplay(BufferedImage source) throws IOException {
        validateDimensions(source.getWidth(), source.getHeight());
        double scale = Math.min((double) DISPLAY_WIDTH / source.getWidth(),
                (double) DISPLAY_HEIGHT / source.getHeight());
        int width = Math.max(1, (int) Math.round(source.getWidth() * scale));
        int height = Math.max(1, (int) Math.round(source.getHeight() * scale));
        BufferedImage resized = new BufferedImage(DISPLAY_WIDTH, DISPLAY_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = resized.createGraphics();
        graphics.setComposite(AlphaComposite.Src);
        graphics.drawImage(source, (DISPLAY_WIDTH - width) / 2, (DISPLAY_HEIGHT - height) / 2,
                width, height, null);
        graphics.dispose();
        return resized;
    }

    private static void validateDimensions(int width, int height) throws IOException {
        if (width <= 0 || height <= 0 || width > MAX_IMAGE_DIMENSION || height > MAX_IMAGE_DIMENSION
                || (long) width * height > MAX_GIF_PIXELS) {
            throw new IOException("Media dimensions exceed the safe 4096x4096 pixel limit.");
        }
    }

    private static BufferedImage copy(BufferedImage source) {
        BufferedImage copy = new BufferedImage(source.getWidth(), source.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = copy.createGraphics();
        graphics.drawImage(source, 0, 0, null);
        graphics.dispose();
        return copy;
    }

    private static int positiveAttribute(IIOMetadata metadata, String nodeName, String attributeName,
            int fallback) throws IOException {
        String value = attribute(metadata, nodeName, attributeName);
        if (value == null) {
            return fallback;
        }
        try {
            int parsed = Integer.parseInt(value);
            return parsed > 0 ? parsed : fallback;
        } catch (NumberFormatException exception) {
            throw new IOException("Invalid GIF metadata value for " + attributeName, exception);
        }
    }

    private static String stringAttribute(IIOMetadata metadata, String nodeName, String attributeName,
            String fallback) throws IOException {
        String value = attribute(metadata, nodeName, attributeName);
        return value == null ? fallback : value;
    }

    private static String attribute(IIOMetadata metadata, String nodeName, String attributeName)
            throws IOException {
        if (metadata == null) {
            return null;
        }
        try {
            String formatName = "LogicalScreenDescriptor".equals(nodeName)
                    ? "javax_imageio_gif_stream_1.0" : "javax_imageio_gif_image_1.0";
            org.w3c.dom.Node root = metadata.getAsTree(formatName);
            javax.xml.xpath.XPath xpath = XPathFactory.newInstance().newXPath();
            org.w3c.dom.Node attribute = (org.w3c.dom.Node) xpath.evaluate(
                    "//" + nodeName + "/@" + attributeName, root, XPathConstants.NODE);
            return attribute == null ? null : attribute.getNodeValue();
        } catch (javax.xml.xpath.XPathExpressionException | IllegalArgumentException exception) {
            throw new IOException("Could not read GIF frame metadata.", exception);
        }
    }

    private static String extension(Path path) {
        String name = path.getFileName().toString();
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private static synchronized boolean isCurrent(long taskGeneration) {
        return generation == taskGeneration && !Thread.currentThread().isInterrupted();
    }

    private static synchronized void publish(BufferedImage image, long taskGeneration) {
        if (generation == taskGeneration) {
            currentFrame = image;
        }
    }

    private static synchronized void setStatus(String value, long taskGeneration) {
        if (generation == taskGeneration) {
            status = value;
        }
    }

    private static final class AnimationFrame {
        private final BufferedImage image;
        private final int delayMillis;

        private AnimationFrame(BufferedImage image, int delayMillis) {
            this.image = image;
            this.delayMillis = delayMillis;
        }
    }
}
