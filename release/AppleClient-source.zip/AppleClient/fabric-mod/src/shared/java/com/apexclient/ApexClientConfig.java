package com.apexclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public final class ApexClientConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("Apex Client");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PROFILE_DIR = FabricLoader.getInstance().getConfigDir().resolve("apexclient");
    private static final Pattern PROFILE_NAME = Pattern.compile("[A-Za-z0-9_-]{1,24}");
    private static final int[] WIDGET_COLORS = {
            0xFFE8F5FF, 0xFF00D2FF, 0xFFFFD166, 0xFFFF6B6B, 0xFFB8F28B, 0xFFC7A6FF
    };
    private static String activeProfile = "default";
    private static ProfileData data = load(activeProfile);

    private ApexClientConfig() {
    }

    public static synchronized boolean isEnabled(String module) {
        return Boolean.TRUE.equals(data.modules.get(module));
    }

    public static synchronized void toggle(String module) {
        data.modules.put(module, !isEnabled(module));
        save();
    }

    public static synchronized int[] getHudPosition(String widget, int defaultX, int defaultY) {
        if (data.positions == null) {
            data.positions = new HashMap<>();
        }
        int[] position = data.positions.get(widget);
        if (position == null || position.length != 2) {
            return new int[] { defaultX, defaultY };
        }
        return new int[] { position[0], position[1] };
    }

    public static synchronized void setHudPosition(String widget, int x, int y) {
        if (data.positions == null) {
            data.positions = new HashMap<>();
        }
        data.positions.put(widget, new int[] { x, y });
        save();
    }

    public static synchronized float getWidgetScale(String widget) {
        WidgetStyle style = widgetStyle(widget);
        if (!Float.isFinite(style.scale) || style.scale < 0.65f || style.scale > 1.75f) {
            style.scale = 1.0f;
        }
        return style.scale;
    }

    public static synchronized int getWidgetTextColor(String widget) {
        int color = widgetStyle(widget).textColor;
        for (int allowed : WIDGET_COLORS) {
            if (allowed == color) {
                return color;
            }
        }
        return WIDGET_COLORS[0];
    }

    public static synchronized boolean isWidgetBackgroundEnabled(String widget) {
        return widgetStyle(widget).background;
    }

    public static synchronized int getWidgetBackgroundOpacity(String widget) {
        WidgetStyle style = widgetStyle(widget);
        style.backgroundOpacity = Math.max(0, Math.min(255, style.backgroundOpacity));
        return style.backgroundOpacity;
    }

    public static synchronized void adjustWidgetScale(String widget, float amount) {
        WidgetStyle style = widgetStyle(widget);
        style.scale = Math.max(0.65f, Math.min(1.75f, Math.round((style.scale + amount) * 20.0f) / 20.0f));
        save();
    }

    public static synchronized void cycleWidgetTextColor(String widget) {
        WidgetStyle style = widgetStyle(widget);
        int nextIndex = 0;
        for (int index = 0; index < WIDGET_COLORS.length; index++) {
            if (WIDGET_COLORS[index] == style.textColor) {
                nextIndex = (index + 1) % WIDGET_COLORS.length;
                break;
            }
        }
        style.textColor = WIDGET_COLORS[nextIndex];
        save();
    }

    public static synchronized void toggleWidgetBackground(String widget) {
        WidgetStyle style = widgetStyle(widget);
        style.background = !style.background;
        save();
    }

    public static synchronized void adjustWidgetBackgroundOpacity(String widget, int amount) {
        WidgetStyle style = widgetStyle(widget);
        style.backgroundOpacity = Math.max(0, Math.min(255, style.backgroundOpacity + amount));
        save();
    }

    public static synchronized int getTntRange() {
        return Math.max(8, Math.min(96, data.tntRange));
    }

    public static synchronized void adjustTntRange(int amount) {
        data.tntRange = Math.max(8, Math.min(96, getTntRange() + amount));
        save();
    }

    public static synchronized void resetWidgetStyle(String widget) {
        if (data.widgetStyles == null) {
            data.widgetStyles = new HashMap<>();
        }
        data.widgetStyles.remove(widget);
        save();
    }

    private static WidgetStyle widgetStyle(String widget) {
        if (data.widgetStyles == null) {
            data.widgetStyles = new HashMap<>();
        }
        return data.widgetStyles.computeIfAbsent(widget, ignored -> new WidgetStyle());
    }

    public static synchronized String getMediaPath() {
        return data.mediaPath == null ? "" : data.mediaPath;
    }

    public static synchronized void setMediaPath(String path) {
        data.mediaPath = path == null ? "" : path;
        save();
    }

    public static synchronized String getActiveProfile() {
        return activeProfile;
    }

    public static synchronized List<String> getProfiles() {
        try {
            Files.createDirectories(PROFILE_DIR);
            List<String> profiles = new ArrayList<>();
            try (var files = Files.list(PROFILE_DIR)) {
                files.filter(path -> path.getFileName().toString().startsWith("profile-")
                                && path.getFileName().toString().endsWith(".json"))
                        .map(path -> path.getFileName().toString()
                                .substring("profile-".length(),
                                        path.getFileName().toString().length() - ".json".length()))
                        .filter(name -> PROFILE_NAME.matcher(name).matches())
                        .forEach(profiles::add);
            }
            if (!profiles.contains("default")) {
                profiles.add("default");
            }
            profiles.sort(Comparator.naturalOrder());
            return profiles;
        } catch (IOException exception) {
            LOGGER.error("Could not list Apex profiles in {}", PROFILE_DIR, exception);
            return List.of(activeProfile);
        }
    }

    public static synchronized boolean selectProfile(String name) {
        if (name == null || !PROFILE_NAME.matcher(name).matches()) {
            return false;
        }
        save();
        activeProfile = name;
        data = load(activeProfile);
        save();
        return true;
    }

    private static ProfileData load(String name) {
        Path file = profilePath(name);
        if (!Files.exists(file)) {
            return new ProfileData();
        }
        try (Reader reader = Files.newBufferedReader(file)) {
            ProfileData loaded = GSON.fromJson(reader, ProfileData.class);
            if (loaded == null || loaded.modules == null) {
                LOGGER.warn("Apex profile {} has invalid contents; using defaults", file);
                return new ProfileData();
            }
            if (loaded.widgetStyles == null) {
                loaded.widgetStyles = new HashMap<>();
            }
            return loaded;
        } catch (IOException | RuntimeException exception) {
            LOGGER.error("Could not load Apex profile {}", file, exception);
            return new ProfileData();
        }
    }

    private static void save() {
        Path file = profilePath(activeProfile);
        Path temporary = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.createDirectories(PROFILE_DIR);
            try (Writer writer = Files.newBufferedWriter(temporary)) {
                GSON.toJson(data, writer);
            }
            try {
                Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            LOGGER.error("Could not save Apex profile {}", file, exception);
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException cleanupFailure) {
                LOGGER.warn("Could not remove incomplete Apex profile file {}", temporary, cleanupFailure);
            }
        }
    }

    private static Path profilePath(String name) {
        return PROFILE_DIR.resolve("profile-" + name + ".json");
    }

    private static final class ProfileData {
        private Map<String, Boolean> modules = new HashMap<>();
        private Map<String, int[]> positions = new HashMap<>();
        private Map<String, WidgetStyle> widgetStyles = new HashMap<>();
        private String mediaPath = "";
        private int tntRange = 48;

        private ProfileData() {
            modules.put("fps", true);
            modules.put("coordinates", true);
            modules.put("clock", true);
        }
    }

    private static final class WidgetStyle {
        private float scale = 1.0f;
        private int textColor = WIDGET_COLORS[0];
        private boolean background = true;
        private int backgroundOpacity = 170;
    }
}
