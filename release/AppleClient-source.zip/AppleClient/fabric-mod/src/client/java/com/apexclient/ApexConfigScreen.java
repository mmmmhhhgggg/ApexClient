package com.apexclient;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ApexConfigScreen extends Screen {
    private static final int SIDEBAR_WIDTH = 144;
    private static final int LIST_TOP = 112;
    private static final int CARD_HEIGHT = 82;
    private static final int CARD_GAP = 8;
    private static final String[][] MODS = {
            {"Fabric API", "fabric-api", "Required Fabric libraries for client mods."},
            {"Sodium", "sodium", "Rendering performance improvements."},
            {"Account Switcher", "ias,in-game-account-switcher,account-switcher", "Switch accounts from the game menu."},
            {"Mod Menu", "modmenu", "In-game configuration screen for supported mods."},
            {"Iris Shaders", "iris", "Shader loading - requires a compatible Sodium build."},
            {"Zoomify", "zoomify", "Configurable client-side zoom - installed when compatible."},
            {"Freelook", "freelook", "Look around without changing movement direction."},
            {"Shade & Saturation", "shadeandsaturation", "Adjust the visual shade and saturation."}
    };

    private final List<Button> moduleButtons = new ArrayList<>();
    private final List<Button> moduleSettingsButtons = new ArrayList<>();
    private final List<Button> categoryButtons = new ArrayList<>();
    private String category = ApexFeatures.HUD;
    private String searchText = "";
    private int scrollRows;
    private EditBox searchBox;
    private EditBox profileBox;
    private Button useProfileButton;
    private Button imageButton;

    public ApexConfigScreen() {
        super(Component.literal("Apple Client"));
    }

    @Override
    protected void init() {
        categoryButtons.clear();
        for (String name : ApexFeatures.CATEGORIES) {
            Button categoryButton = Button.builder(categoryMessage(name), clicked -> selectCategory(name))
                    .bounds(14, 67 + categoryButtons.size() * 34, SIDEBAR_WIDTH - 24, 27)
                    .build();
            categoryButtons.add(addRenderableWidget(categoryButton));
        }

        searchBox = new EditBox(font, contentX(), 54, contentWidth(), 24, Component.literal("Search"));
        searchBox.setHint(Component.literal("Search modules..."));
        searchBox.setMaxLength(48);
        searchBox.setResponder(value -> {
            searchText = value;
            scrollRows = 0;
            rebuildModuleButtons();
        });
        addRenderableWidget(searchBox);

        profileBox = new EditBox(font, contentX(), 102, 150, 24, Component.literal("Profile"));
        profileBox.setMaxLength(24);
        profileBox.setValue(ApexClientConfig.getActiveProfile());
        addRenderableWidget(profileBox);
        useProfileButton = addRenderableWidget(Button.builder(Component.literal("USE"), clicked -> useProfile())
                .bounds(contentX() + 158, 102, 116, 24).build());
        imageButton = addRenderableWidget(Button.builder(Component.literal("SET IMAGE"), clicked -> {
            ApexMedia.chooseFile();
            rebuildModuleButtons();
        })
                .bounds(width - 326, height - 34, 104, 24).build());
        updateProfileVisibility();
        addRenderableWidget(Button.builder(Component.literal("EDIT HUD"),
                        clicked -> Minecraft.getInstance().setScreenAndShow(new ApexHudEditorScreen(this)))
                .bounds(width - 210, height - 34, 106, 24).build());
        addRenderableWidget(Button.builder(Component.literal("CLOSE"), clicked -> onClose())
                .bounds(width - 96, height - 34, 78, 24).build());
        rebuildModuleButtons();
    }

    private Component categoryMessage(String name) {
        return Component.literal((name.equals(category) ? "> " : "  ") + name.toUpperCase(Locale.ROOT));
    }

    private void selectCategory(String name) {
        category = name;
        scrollRows = 0;
        for (int i = 0; i < categoryButtons.size(); i++) {
            categoryButtons.get(i).setMessage(categoryMessage(ApexFeatures.CATEGORIES.get(i)));
        }
        updateProfileVisibility();
        rebuildModuleButtons();
    }

    private void useProfile() {
        if (ApexClientConfig.selectProfile(profileBox.getValue())) {
            profileBox.setValue(ApexClientConfig.getActiveProfile());
        } else {
            profileBox.setHint(Component.literal("Use letters, digits, _ or -"));
        }
        rebuildModuleButtons();
    }

    private int contentX() {
        return SIDEBAR_WIDTH + 22;
    }

    private int contentWidth() {
        return Math.max(100, width - contentX() - 18);
    }

    private void updateProfileVisibility() {
        if (profileBox != null) {
            profileBox.visible = ApexFeatures.SETTINGS.equals(category);
            profileBox.active = profileBox.visible;
        }
        if (useProfileButton != null) {
            useProfileButton.visible = ApexFeatures.SETTINGS.equals(category);
            useProfileButton.active = useProfileButton.visible;
        }
        if (imageButton != null) {
            imageButton.visible = ApexFeatures.HUD.equals(category);
            imageButton.active = imageButton.visible;
        }
    }

    private List<CardData> getCards() {
        String needle = searchText.trim().toLowerCase(Locale.ROOT);
        List<CardData> cards = new ArrayList<>();
        if (ApexFeatures.MODS.equals(category)) {
            for (String[] mod : MODS) {
                if (!matches(needle, mod[0], mod[2])) continue;
                boolean installed = false;
                for (String id : mod[1].split(",")) {
                    if (FabricLoader.getInstance().isModLoaded(id)) {
                        installed = true;
                        break;
                    }
                }
                cards.add(new CardData(mod[0], mod[2], installed, installed ? "INSTALLED" : "NOT INSTALLED",
                        null, false));
            }
            return cards;
        }

        if (ApexFeatures.SETTINGS.equals(category)) {
            cards.add(new CardData("HUD Profiles", "Save and switch between independent HUD layouts.",
                    true, ApexClientConfig.getActiveProfile(), null, false));
            return cards;
        }

        for (ApexFeatures.Feature feature : ApexFeatures.ALL) {
            if (feature.category.equals(category) && matches(needle, feature.label, feature.description)) {
                boolean enabled = ApexClientConfig.isEnabled(feature.id);
                cards.add(new CardData(feature.label, feature.description, enabled,
                        enabled ? "ON" : "OFF", feature, true));
            }
        }
        return cards;
    }

    private static boolean matches(String needle, String title, String description) {
        return needle.isEmpty() || title.toLowerCase(Locale.ROOT).contains(needle)
                || description.toLowerCase(Locale.ROOT).contains(needle);
    }

    private void rebuildModuleButtons() {
        for (Button button : moduleButtons) {
            removeWidget(button);
        }
        moduleButtons.clear();
        for (Button button : moduleSettingsButtons) {
            removeWidget(button);
        }
        moduleSettingsButtons.clear();

        List<CardData> cards = getCards();
        int cols = columns();
        int cardWidth = (contentWidth() - (cols - 1) * CARD_GAP) / cols;
        int start = scrollRows * cols;
        int end = Math.min(cards.size(), start + visibleRows() * cols);
        for (int i = start; i < end; i++) {
            CardData card = cards.get(i);
            if (!card.toggle) continue;
            int offset = i - start;
            int cardX = contentX() + (offset % cols) * (cardWidth + CARD_GAP);
            int cardY = cardsTop() + (offset / cols) * (CARD_HEIGHT + CARD_GAP);
            Button toggle = Button.builder(buttonMessage(card), clicked -> {
                ApexClientConfig.toggle(card.feature.id);
                clicked.setMessage(buttonMessage(card));
            }).bounds(cardX + cardWidth - 66, cardY + 54, 56, 21).build();
            moduleButtons.add(addRenderableWidget(toggle));
            Button settings = Button.builder(Component.literal("SET"), clicked ->
                    Minecraft.getInstance().setScreenAndShow(
                            new ApexModuleSettingsScreen(this, card.feature.id, card.title)))
                    .bounds(cardX + cardWidth - 124, cardY + 54, 50, 21).build();
            moduleSettingsButtons.add(addRenderableWidget(settings));
        }
    }

    private Component buttonMessage(CardData card) {
        return Component.literal(ApexClientConfig.isEnabled(card.feature.id) ? "ON" : "OFF");
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (scrollY != 0 && mouseX >= contentX()) {
            int maxRows = (getCards().size() + columns() - 1) / columns();
            scrollRows = Math.max(0, Math.min(Math.max(0, maxRows - visibleRows()),
                    scrollRows + (scrollY < 0 ? 1 : -1)));
            rebuildModuleButtons();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    private int columns() {
        return Math.max(1, Math.min(4, (contentWidth() + CARD_GAP) / 190));
    }

    private int visibleRows() {
        return Math.max(1, (height - cardsTop() - 54) / (CARD_HEIGHT + CARD_GAP));
    }

    private int cardsTop() {
        return ApexFeatures.SETTINGS.equals(category) ? 154
                : ApexFeatures.MODS.equals(category) ? 136 : LIST_TOP;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, 0x70080D16);
        graphics.fill(8, 8, width - 8, height - 8, 0xB8101724);
        graphics.fill(8, 8, width - 8, 42, 0xE0111D2B);
        graphics.fill(8, 42, SIDEBAR_WIDTH, height - 8, 0xD80C131D);
        graphics.fill(SIDEBAR_WIDTH, 42, SIDEBAR_WIDTH + 1, height - 8, 0xFF243548);
        graphics.fill(8, 41, width - 8, 43, 0xFF00D2FF);
        graphics.text(font, "APPLE CLIENT", 22, 20, 0xFF00D2FF);
        graphics.text(font, "CATEGORIES", 20, 53, 0xFF8FA5B9);

        for (int i = 0; i < ApexFeatures.CATEGORIES.size(); i++) {
            String name = ApexFeatures.CATEGORIES.get(i);
            int y = 72 + i * 34;
            boolean selected = name.equals(category);
            if (selected) {
                graphics.fill(14, y - 5, SIDEBAR_WIDTH - 10, y + 22, 0xFF15364A);
                graphics.fill(14, y - 5, 17, y + 22, 0xFF00D2FF);
            }
        }

        int x = contentX();
        graphics.text(font, category.toUpperCase(Locale.ROOT), x, 19, 0xFFF2F7FC);
        graphics.text(font, "Apple Client - " + Minecraft.getInstance().getLaunchedVersion(), x + 130, 20,
                0xFF8FA5B9);
        graphics.text(font, "Search modules", x, 45, 0xFFAAB8C7);
        graphics.fill(x - 1, 53, x + contentWidth() + 1, 80, 0xFF0B1119);
        graphics.fill(x - 1, 53, x + contentWidth() + 1, 54, 0xFF315064);

        if (ApexFeatures.SETTINGS.equals(category)) {
            graphics.text(font, "Profile name", x, 87, 0xFFAAB8C7);
            graphics.text(font, "Profiles save module switches and HUD positions.", x, 135,
                    0xFF8FA5B9);
        }
        if (ApexFeatures.MODS.equals(category)) {
            graphics.text(font, "The launcher installs compatible Fabric add-ons before game startup.",
                    x, 88, 0xFF8FA5B9);
        }

        List<CardData> cards = getCards();
        int cols = columns();
        int cardWidth = (contentWidth() - (cols - 1) * CARD_GAP) / cols;
        int start = scrollRows * cols;
        int end = Math.min(cards.size(), start + visibleRows() * cols);
        for (int i = start; i < end; i++) {
            CardData card = cards.get(i);
            int offset = i - start;
            int col = offset % cols;
            int row = offset / cols;
            int cardX = x + col * (cardWidth + CARD_GAP);
            int cardY = cardsTop() + row * (CARD_HEIGHT + CARD_GAP);
            boolean hovered = mouseX >= cardX && mouseX <= cardX + cardWidth
                    && mouseY >= cardY && mouseY <= cardY + CARD_HEIGHT;
            graphics.fill(cardX, cardY, cardX + cardWidth, cardY + CARD_HEIGHT,
                    hovered ? 0xFF202F40 : 0xFF182331);
            graphics.fill(cardX, cardY, cardX + 2, cardY + CARD_HEIGHT, card.enabled
                    ? 0xFF00D2FF : (hovered ? 0xFF60758A : 0xFF34465A));
            graphics.fill(cardX, cardY, cardX + cardWidth, cardY + 1, card.enabled
                    ? 0xFF00D2FF : 0xFF34465A);
            graphics.text(font, trim(card.title, cardWidth - 18), cardX + 10, cardY + 10, 0xFFF1F6FC);
            graphics.text(font, trim(card.description, cardWidth - 18), cardX + 10, cardY + 28,
                    0xFF9EADBD);
            int pillColor = card.status.equals("ON") || card.status.equals("INSTALLED")
                    ? 0xFF00D2FF : 0xFF667789;
            int statusRight = card.toggle ? cardX + cardWidth - 132 : cardX + cardWidth - 10;
            graphics.fill(cardX + 10, cardY + 57, statusRight, cardY + 77, 0xFF0D151F);
            graphics.text(font, trim(card.status, statusRight - cardX - 24), cardX + 17, cardY + 63, pillColor);
        }

        if (cards.isEmpty()) {
            graphics.fill(x, cardsTop(), x + contentWidth(), cardsTop() + 84, 0xFF182331);
            graphics.text(font, searchText.isEmpty()
                            ? "No active modules in this category yet."
                            : "No modules match your search.",
                    x + 16, cardsTop() + 22, 0xFFF1F6FC);
            graphics.text(font, "Unavailable features are hidden instead of shown as fake switches.",
                    x + 16, cardsTop() + 44, 0xFF9EADBD);
        }

        graphics.text(font, "SET IMAGE chooses PNG, JPG, GIF or looping H.264 MP4. EDIT HUD moves widgets.",
                x, height - 24, 0xFFB1BECC);
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
    }

    private String trim(String text, int maxWidth) {
        if (font.width(text) <= maxWidth) return text;
        String result = text;
        while (!result.isEmpty() && font.width(result + "...") > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result + "...";
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreenAndShow(null);
    }

    private static final class CardData {
        private final String title;
        private final String description;
        private final boolean enabled;
        private final String status;
        private final ApexFeatures.Feature feature;
        private final boolean toggle;

        private CardData(String title, String description, boolean enabled, String status,
                ApexFeatures.Feature feature, boolean toggle) {
            this.title = title;
            this.description = description;
            this.enabled = enabled;
            this.status = status;
            this.feature = feature;
            this.toggle = toggle;
        }
    }

}
