package com.apexclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class ApexModuleSettingsScreen extends Screen {
    private static final List<String> COLOR_NAMES =
            List.of("Ice", "Cyan", "Gold", "Red", "Lime", "Violet");

    private final Screen parent;
    private final String moduleId;
    private final String moduleName;
    private Button colorButton;
    private Button backgroundButton;
    private Button tntRangeButton;

    public ApexModuleSettingsScreen(Screen parent, String moduleId, String moduleName) {
        super(Component.literal(moduleName + " Settings"));
        this.parent = parent;
        this.moduleId = moduleId;
        this.moduleName = moduleName;
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("-"), button -> {
            ApexClientConfig.adjustWidgetScale(moduleId, -0.05f);
            updateMessages();
        }).bounds(width - 164, 112, 48, 22).build());
        addRenderableWidget(Button.builder(Component.literal("+"), button -> {
            ApexClientConfig.adjustWidgetScale(moduleId, 0.05f);
            updateMessages();
        }).bounds(width - 108, 112, 48, 22).build());

        colorButton = addRenderableWidget(Button.builder(colorMessage(), button -> {
            ApexClientConfig.cycleWidgetTextColor(moduleId);
            updateMessages();
        }).bounds(width - 164, 151, 104, 22).build());

        addRenderableWidget(Button.builder(Component.literal("-"), button -> {
            ApexClientConfig.adjustWidgetBackgroundOpacity(moduleId, -16);
            updateMessages();
        }).bounds(width - 164, 190, 48, 22).build());
        addRenderableWidget(Button.builder(Component.literal("+"), button -> {
            ApexClientConfig.adjustWidgetBackgroundOpacity(moduleId, 16);
            updateMessages();
        }).bounds(width - 108, 190, 48, 22).build());

        backgroundButton = addRenderableWidget(Button.builder(backgroundMessage(), button -> {
            ApexClientConfig.toggleWidgetBackground(moduleId);
            updateMessages();
        }).bounds(width - 164, 229, 104, 22).build());

        if ("tnt_timer".equals(moduleId)) {
            tntRangeButton = addRenderableWidget(Button.builder(tntRangeMessage(), button -> {
                ApexClientConfig.adjustTntRange(8);
                updateMessages();
            }).bounds(width - 164, 268, 104, 22).build());
            addRenderableWidget(Button.builder(Component.literal("- 8"), button -> {
                ApexClientConfig.adjustTntRange(-8);
                updateMessages();
            }).bounds(width - 220, 268, 48, 22).build());
        }
        if ("image".equals(moduleId)) {
            addRenderableWidget(Button.builder(Component.literal("CHOOSE FILE"), button -> {
                ApexMedia.chooseFile();
                button.setMessage(Component.literal("CHOOSE FILE"));
            }).bounds(width - 220, 268, 104, 22).build());
        }

        addRenderableWidget(Button.builder(Component.literal("RESET STYLE"),
                button -> {
                    ApexClientConfig.resetWidgetStyle(moduleId);
                    updateMessages();
                }).bounds(width - 220, height - 38, 104, 24).build());
        addRenderableWidget(Button.builder(Component.literal("BACK"), button -> onClose())
                .bounds(width - 104, height - 38, 88, 24).build());
    }

    private void updateMessages() {
        colorButton.setMessage(colorMessage());
        backgroundButton.setMessage(backgroundMessage());
        if (tntRangeButton != null) {
            tntRangeButton.setMessage(tntRangeMessage());
        }
    }

    private Component colorMessage() {
        int color = ApexClientConfig.getWidgetTextColor(moduleId);
        int index = List.of(0xFFE8F5FF, 0xFF00D2FF, 0xFFFFD166, 0xFFFF6B6B,
                0xFFB8F28B, 0xFFC7A6FF).indexOf(color);
        return Component.literal(COLOR_NAMES.get(Math.max(0, index)));
    }

    private Component backgroundMessage() {
        return Component.literal(ApexClientConfig.isWidgetBackgroundEnabled(moduleId) ? "ON" : "OFF");
    }

    private Component tntRangeMessage() {
        return Component.literal(ApexClientConfig.getTntRange() + " blocks");
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, 0x88060B12);
        graphics.fill(12, 12, width - 12, height - 12, 0xD8101724);
        graphics.fill(12, 48, width - 12, 50, 0xFF00D2FF);
        graphics.text(font, moduleName.toUpperCase() + " SETTINGS", 24, 25, 0xFF00D2FF);
        graphics.text(font, "Scale", 28, 119, 0xFFE8F5FF);
        graphics.text(font, String.format(java.util.Locale.ROOT, "%.2fx",
                ApexClientConfig.getWidgetScale(moduleId)), width - 214, 119, 0xFF9EADBD);
        graphics.text(font, "Text color", 28, 158, 0xFFE8F5FF);
        graphics.fill(width - 52, 152, width - 32, 172, ApexClientConfig.getWidgetTextColor(moduleId));
        graphics.text(font, "Background opacity", 28, 197, 0xFFE8F5FF);
        graphics.text(font, ApexClientConfig.getWidgetBackgroundOpacity(moduleId) + " / 255",
                width - 214, 197, 0xFF9EADBD);
        graphics.text(font, "Background", 28, 236, 0xFFE8F5FF);
        if ("tnt_timer".equals(moduleId)) {
            graphics.text(font, "Detection range", 28, 275, 0xFFE8F5FF);
        } else if ("image".equals(moduleId)) {
            graphics.text(font, "Local PNG, JPG, GIF or H.264 MP4", 28, 275, 0xFFE8F5FF);
        }

        List<String> previewLines = ApexHud.groupLines(ApexHud.getWidgetLines())
                .getOrDefault(moduleId, List.of(moduleName));
        ApexHud.drawWidget(graphics, moduleId, previewLines, 28, 66, true, mouseX, mouseY);
        graphics.text(font, "Changes save to the active profile.", 28, height - 30, 0xFF9EADBD);
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreenAndShow(parent);
    }
}
