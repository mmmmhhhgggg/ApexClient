package com.apexclient;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.item.ItemStack;
import com.mojang.blaze3d.platform.NativeImage;

import java.awt.image.BufferedImage;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ApexHud {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final Deque<Long> LEFT_CLICKS = new ArrayDeque<>();
    private static final Deque<Long> RIGHT_CLICKS = new ArrayDeque<>();
    private static final Identifier MEDIA_TEXTURE_ID =
            Identifier.fromNamespaceAndPath("apexclient", "media/frame");
    private static boolean leftWasDown;
    private static boolean rightWasDown;
    private static boolean editorOpen;
    private static DynamicTexture mediaTexture;
    private static BufferedImage uploadedFrame;
    private static int mediaTextureWidth;
    private static int mediaTextureHeight;

    private ApexHud() {
    }

    public static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("apexclient", "hud"),
                (graphics, deltaTracker) -> render(graphics));
    }

    private static void render(GuiGraphicsExtractor graphics) {
        Minecraft client = Minecraft.getInstance();
        if (editorOpen) {
            return;
        }
        updateClicks(client, System.currentTimeMillis());
        Map<String, List<String>> groups = groupLines(getWidgetLines());
        int defaultY = 8;
        for (Map.Entry<String, List<String>> entry : groups.entrySet()) {
            String widget = entry.getKey();
            List<String> lines = entry.getValue();
            int[] position = ApexClientConfig.getHudPosition(widget, 8, defaultY);
            drawWidget(graphics, widget, lines, position[0], position[1], false, -1, -1);
            defaultY += widgetHeight(widget, lines) + 6;
        }
    }

    static void setEditorOpen(boolean open) {
        editorOpen = open;
    }

    static List<String> getWidgetLines() {
        Minecraft client = Minecraft.getInstance();
        List<String> lines = new ArrayList<>();
        if (ApexClientConfig.isEnabled("fps")) {
            lines.add("FPS  " + client.getFps());
        }
        if (ApexClientConfig.isEnabled("cps")) {
            lines.add("CPS  L " + LEFT_CLICKS.size() + "   R " + RIGHT_CLICKS.size());
        }
        if (ApexClientConfig.isEnabled("network_memory")) {
            lines.add("PING  " + getPing(client) + " ms");
            Runtime runtime = Runtime.getRuntime();
            long usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024);
            long maxMb = runtime.maxMemory() / (1024 * 1024);
            lines.add("MEM  " + usedMb + " / " + maxMb + " MB");
        }
        if (ApexClientConfig.isEnabled("clock")) {
            lines.add("TIME  " + LocalTime.now().format(CLOCK));
        }
        if (client.player != null && client.level != null) {
            if (ApexClientConfig.isEnabled("coordinates")) {
                Direction facing = Direction.fromYRot(client.player.getYRot());
                lines.add(String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f  %s",
                        client.player.getX(), client.player.getY(), client.player.getZ(),
                        facing.getName().toUpperCase(Locale.ROOT)));
            }
            if (ApexClientConfig.isEnabled("keystrokes")) {
                lines.add("KEYS  " + pressed(client.options.keyUp.isDown(), "W") + " "
                        + pressed(client.options.keyLeft.isDown(), "A") + " "
                        + pressed(client.options.keyDown.isDown(), "S") + " "
                        + pressed(client.options.keyRight.isDown(), "D")
                        + "   LMB " + pressed(leftWasDown, "") + " RMB " + pressed(rightWasDown, ""));
            }
            if (ApexClientConfig.isEnabled("biome")) {
                String biome = client.level.getBiome(client.player.blockPosition()).unwrapKey()
                        .map(Object::toString).orElse("unknown");
                lines.add("BIOME  " + biome);
            }
            if (ApexClientConfig.isEnabled("movement_speed")) {
                double velocityX = client.player.getDeltaMovement().x;
                double velocityZ = client.player.getDeltaMovement().z;
                double speed = Math.sqrt(velocityX * velocityX + velocityZ * velocityZ) * 20.0;
                lines.add(String.format(Locale.ROOT, "SPEED  %.2f blocks/s", speed));
            }
            if (ApexClientConfig.isEnabled("world_time")) {
                long totalTime = client.level.getOverworldClockTime();
                long dayTime = Math.floorMod(totalTime, 24000L);
                int hour = (int) ((dayTime / 1000L + 6L) % 24L);
                int minute = (int) (dayTime % 1000L * 60L / 1000L);
                long day = Math.floorDiv(totalTime, 24000L) + 1L;
                lines.add(String.format(Locale.ROOT, "WORLD  Day %d  %02d:%02d", day, hour, minute));
            }
            if (ApexClientConfig.isEnabled("dimension")) {
                lines.add("DIMENSION  " + client.level.dimension());
            }
            if (ApexClientConfig.isEnabled("chunk")) {
                lines.add("CHUNK  " + (client.player.blockPosition().getX() >> 4)
                        + "  " + (client.player.blockPosition().getZ() >> 4));
            }
            if (ApexClientConfig.isEnabled("armor")) {
                for (EquipmentSlot slot : List.of(EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                        EquipmentSlot.LEGS, EquipmentSlot.FEET)) {
                    ItemStack stack = client.player.getItemBySlot(slot);
                    if (!stack.isEmpty()) {
                        lines.add("ARMOR  " + stack.getHoverName().getString() + "  "
                                + remainingDurability(stack) + "%");
                    }
                }
                ItemStack held = client.player.getMainHandItem();
                if (!held.isEmpty() && held.isDamageableItem()) {
                    lines.add("ITEM  " + held.getHoverName().getString() + "  "
                            + remainingDurability(held) + "%");
                }
            }
            if (ApexClientConfig.isEnabled("effects")) {
                client.player.getActiveEffects().forEach(effect -> lines.add("EFFECT  "
                        + effect.getEffect().value().getDisplayName().getString() + "  "
                        + formatDuration(effect.getDuration())));
            }
            if (ApexClientConfig.isEnabled("tnt_timer")) {
                PrimedTnt nearest = null;
                double nearestDistance = Double.MAX_VALUE;
                double tntRange = ApexClientConfig.getTntRange();
                for (PrimedTnt tnt : client.level.getEntitiesOfClass(PrimedTnt.class,
                        client.player.getBoundingBox().inflate(tntRange))) {
                    double distance = client.player.distanceToSqr(tnt);
                    if (distance > tntRange * tntRange) {
                        continue;
                    }
                    if (distance < nearestDistance) {
                        nearest = tnt;
                        nearestDistance = distance;
                    }
                }
                if (nearest != null) {
                    long fuseMillis = Math.max(0, nearest.getFuse()) * 50L;
                    lines.add(String.format(Locale.ROOT, "TNT  %.2f s  %.1f m",
                            fuseMillis / 1000.0, Math.sqrt(nearestDistance)));
                } else {
                    lines.add("TNT  no primed TNT within " + (int) tntRange + " m");
                }
            }
        }
        if (ApexClientConfig.isEnabled("image")) {
            lines.add(ApexMedia.getLabel());
        }
        return lines;
    }

    static Map<String, List<String>> groupLines(List<String> lines) {
        Map<String, List<String>> groups = new LinkedHashMap<>();
        for (String line : lines) {
            groups.computeIfAbsent(widgetId(line), ignored -> new ArrayList<>()).add(line);
        }
        return groups;
    }

    static int widgetWidth(String widget, List<String> lines) {
        int width;
        if ("image".equals(widget)) {
            width = 160;
        } else {
            Minecraft client = Minecraft.getInstance();
            width = lines.stream().mapToInt(client.font::width).max().orElse(0) + 8;
        }
        return Math.round(width * ApexClientConfig.getWidgetScale(widget));
    }

    static int widgetHeight(String widget, List<String> lines) {
        int height = "image".equals(widget) ? 90 : Math.max(1, lines.size()) * 16;
        return Math.round(height * ApexClientConfig.getWidgetScale(widget));
    }

    static void drawWidget(GuiGraphicsExtractor graphics, String widget, List<String> lines,
            int x, int y, boolean editing, int mouseX, int mouseY) {
        Minecraft client = Minecraft.getInstance();
        float scale = ApexClientConfig.getWidgetScale(widget);
        int baseWidth = "image".equals(widget) ? 160
                : lines.stream().mapToInt(client.font::width).max().orElse(0) + 8;
        int baseHeight = "image".equals(widget) ? 90 : Math.max(1, lines.size()) * 16;
        boolean hovered = editing && mouseX >= x && mouseX <= x + widgetWidth(widget, lines)
                && mouseY >= y && mouseY <= y + widgetHeight(widget, lines);
        graphics.pose().pushMatrix();
        try {
            graphics.pose().translate(x, y);
            graphics.pose().scale(scale, scale);
            if (ApexClientConfig.isWidgetBackgroundEnabled(widget)) {
                int opacity = ApexClientConfig.getWidgetBackgroundOpacity(widget);
                graphics.fill(0, 0, baseWidth, baseHeight,
                        hovered ? 0xE51A3448 : (opacity << 24) | 0x00101724);
            } else if (editing) {
                graphics.fill(0, 0, baseWidth, 1, hovered ? 0xFF00D2FF : 0xFF34465A);
            }
            if ("image".equals(widget)) {
                BufferedImage frame = ApexMedia.getCurrentFrame();
                if (frame == null) {
                    graphics.text(client.font, ApexMedia.getStatus(), 5, 6, 0xFFD0DCE8);
                } else {
                    uploadFrame(client, frame);
                    graphics.blit(MEDIA_TEXTURE_ID, 0, 0, baseWidth, baseHeight, 0.0f, 0.0f, 1.0f, 1.0f);
                }
                return;
            }
            int textColor = ApexClientConfig.getWidgetTextColor(widget);
            for (int index = 0; index < lines.size(); index++) {
                graphics.text(client.font, lines.get(index), 4, 3 + index * 16, textColor);
            }
        } finally {
            graphics.pose().popMatrix();
        }
    }

    private static void uploadFrame(Minecraft client, BufferedImage frame) {
        if (uploadedFrame == frame) {
            return;
        }
        NativeImage pixels = new NativeImage(frame.getWidth(), frame.getHeight(), false);
        for (int y = 0; y < frame.getHeight(); y++) {
            for (int x = 0; x < frame.getWidth(); x++) {
                pixels.setPixel(x, y, frame.getRGB(x, y));
            }
        }
        if (mediaTexture == null || mediaTextureWidth != frame.getWidth()
                || mediaTextureHeight != frame.getHeight()) {
            if (mediaTexture != null) {
                client.getTextureManager().release(MEDIA_TEXTURE_ID);
            }
            mediaTexture = new DynamicTexture(() -> "Apex media", pixels);
            client.getTextureManager().register(MEDIA_TEXTURE_ID, mediaTexture);
            mediaTextureWidth = frame.getWidth();
            mediaTextureHeight = frame.getHeight();
        } else {
            mediaTexture.setPixels(pixels);
        }
        mediaTexture.upload();
        uploadedFrame = frame;
    }

    private static String widgetId(String line) {
        if (line.startsWith("FPS  ")) return "fps";
        if (line.startsWith("CPS  ")) return "cps";
        if (line.startsWith("PING  ") || line.startsWith("MEM  ")) return "network_memory";
        if (line.startsWith("TIME  ")) return "clock";
        if (line.startsWith("XYZ  ")) return "coordinates";
        if (line.startsWith("KEYS  ")) return "keystrokes";
        if (line.startsWith("BIOME  ")) return "biome";
        if (line.startsWith("SPEED  ")) return "movement_speed";
        if (line.startsWith("WORLD  ")) return "world_time";
        if (line.startsWith("DIMENSION  ")) return "dimension";
        if (line.startsWith("CHUNK  ")) return "chunk";
        if (line.startsWith("ARMOR  ") || line.startsWith("ITEM  ")) return "armor";
        if (line.startsWith("EFFECT  ")) return "effects";
        if (line.startsWith("TNT  ")) return "tnt_timer";
        if (line.startsWith("IMAGE  ")) return "image";
        throw new IllegalArgumentException("Unknown Apex HUD widget line: " + line);
    }

    private static void updateClicks(Minecraft client, long now) {
        boolean leftDown = client.getWindow() != null && client.mouseHandler.isLeftPressed();
        boolean rightDown = client.getWindow() != null && client.mouseHandler.isRightPressed();
        if (leftDown && !leftWasDown) {
            LEFT_CLICKS.addLast(now);
        }
        if (rightDown && !rightWasDown) {
            RIGHT_CLICKS.addLast(now);
        }
        leftWasDown = leftDown;
        rightWasDown = rightDown;
        prune(LEFT_CLICKS, now);
        prune(RIGHT_CLICKS, now);
    }

    private static void prune(Deque<Long> clicks, long now) {
        while (!clicks.isEmpty() && now - clicks.peekFirst() >= 1000) {
            clicks.removeFirst();
        }
    }

    private static String getPing(Minecraft client) {
        if (client.getConnection() == null || client.player == null) {
            return "--";
        }
        var playerInfo = client.getConnection().getPlayerInfo(client.player.getUUID());
        return playerInfo == null ? "--" : Integer.toString(playerInfo.getLatency());
    }

    private static String pressed(boolean down, String label) {
        return down ? "[" + label + "]" : label;
    }

    private static int remainingDurability(ItemStack stack) {
        if (stack.getMaxDamage() <= 0) {
            return 100;
        }
        return Math.max(0, (stack.getMaxDamage() - stack.getDamageValue()) * 100 / stack.getMaxDamage());
    }

    private static String formatDuration(int ticks) {
        int totalSeconds = Math.max(0, ticks) / 20;
        return String.format(Locale.ROOT, "%d:%02d", totalSeconds / 60, totalSeconds % 60);
    }
}
